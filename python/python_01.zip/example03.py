#!/usr/bin/env python3

def task():
    print("Hello World!")


if __name__ == '__main__':
    task()