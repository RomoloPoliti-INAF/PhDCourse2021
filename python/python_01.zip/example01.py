#! /usr/bin/env python3
'''
    Module description
'''
__author__ = 'Romolo Politi'
__copyright__ = 'Copyright 2021, Test Project'
__credits__ = ['Romolo Politi', 'Antonio Franco', 'Fulvio Sarcinella']
__license__ = 'GNU GPLv3' 
__version__ = '0.1.0'
__maintainer__ = 'Romolo Politi'
__email__ = 'Romolo.Politiinaf.it'
__status__ = 'Prototype'
__date__ = "2021/06/22"

import os

print("Hello, World!")



